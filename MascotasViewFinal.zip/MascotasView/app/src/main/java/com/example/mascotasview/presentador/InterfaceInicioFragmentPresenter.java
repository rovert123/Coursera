package com.example.mascotasview.presentador;

public interface InterfaceInicioFragmentPresenter {

    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();
}

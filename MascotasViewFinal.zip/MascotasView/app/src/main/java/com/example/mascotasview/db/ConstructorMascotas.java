package com.example.mascotasview.db;

import android.content.ContentValues;
import android.content.Context;

import com.example.mascotasview.R;
import com.example.mascotasview.pojo.Mascota;

import java.util.ArrayList;

public class ConstructorMascotas {

    private static final int LIKE = 1;
    private Context context;
    public ConstructorMascotas(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> obtenerDatos(){
        /*ArrayList<Mascota> mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Labrador", 8 , R.drawable.labrador, 5));
        mascotas.add(new Mascota("Bobtail", 4, R.drawable.bobtail, 1));
        mascotas.add(new Mascota("Shiba Inu", 3, R.drawable.shiba_inu_taiki, 2));
        mascotas.add(new Mascota("Shar Pei", 2, R.drawable.shar_pei, 3));
        mascotas.add(new Mascota("Pastor alemán", 7, R.drawable.pastor_aleman, 5));
        return mascotas;*/

        BaseDatos db = new BaseDatos(context);
        insertarCincoMascotas(db);
        return db.obtenerTodasLasMascotas();
    }

    public void insertarCincoMascotas (BaseDatos db){
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_NOMBRE, "Labrador");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_EDAD, "8");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_FOTO, R.drawable.labrador);

        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_NOMBRE, "Bobtail");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_EDAD, "4");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_FOTO, R.drawable.bobtail);

        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_NOMBRE, "Shiba Inu");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_EDAD, "3");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_FOTO, R.drawable.shiba_inu_taiki);

        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_NOMBRE, "Shar Pei");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_EDAD, "2");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_FOTO, R.drawable.shar_pei);

        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_NOMBRE, "Pastor alemán");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_EDAD, "7");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTA_FOTO, R.drawable.pastor_aleman);

        db.insertarMascota(contentValues);
    }

    public void darLikeMascota(Mascota mascota){
        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTA_ID_MASCOTA, mascota.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTA_NUMERO_LIKES, LIKE);
        db.insertarLikeMacsota(contentValues);
    }

    public int obtenerLikesMascota(Mascota mascota){
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikesMascota(mascota);
    }

    public ArrayList<Mascota> obtenerDatos2(){
        ArrayList<Mascota> mascotas2 = new ArrayList<Mascota>();
        mascotas2.add(new Mascota(R.drawable.shar_pei, 1));
        mascotas2.add(new Mascota(R.drawable.shar_pei, 2));
        mascotas2.add(new Mascota(R.drawable.shar_pei, 3));
        mascotas2.add(new Mascota(R.drawable.shar_pei, 4));
        mascotas2.add(new Mascota(R.drawable.shar_pei, 5));
        mascotas2.add(new Mascota(R.drawable.shar_pei, 6));
        return mascotas2;
    }
}

package com.example.mascotasview.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mascotasview.R;
import com.example.mascotasview.pojo.Mascota;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MascotaAdaptador2 extends RecyclerView.Adapter<MascotaAdaptador2.MascotaViewHolder2> {

    ArrayList<Mascota> mascotas2;
    Activity activity;

    public MascotaAdaptador2(ArrayList<Mascota> mascotas2, Activity activity){
        this.mascotas2 = mascotas2;
        this.activity = activity;
    }

    @NonNull
    @Override
    public MascotaViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view_2,parent,false);
        return new MascotaViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MascotaViewHolder2 holder, int position) {
        Mascota mascota = mascotas2.get(position);
        holder.imMascota.setImageResource(mascota.getFoto());
        holder.txvLikesCV.setText(String.valueOf(mascota.getLikes()));
    }

    @Override
    public int getItemCount() {
        return mascotas2.size();
    }

    public static class MascotaViewHolder2 extends RecyclerView.ViewHolder {

        private ImageView imMascota, hueso_color;
        private TextView  txvLikesCV;
        public CardView MascotaCardView2;



        public MascotaViewHolder2(@NonNull View itemView) {
            super(itemView);
            imMascota = (ImageView) itemView.findViewById(R.id.imMascota);
            txvLikesCV   = (TextView) itemView.findViewById(R.id.tvNumeroPerro);
            hueso_color = (ImageView) itemView.findViewById(R.id.Huesito_Amarillo);
            MascotaCardView2 = (CardView) itemView.findViewById(R.id.cvMascotaCardView2);
        }
    }

}

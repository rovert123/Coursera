package com.example.mascotasview.interfaces;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import com.example.mascotasview.R;
import com.example.mascotasview.adapter.MascotaAdaptador;
import com.example.mascotasview.pojo.Mascota;

public class MascotasFavoritas extends AppCompatActivity {

    ArrayList<Mascota> mascotas;

    private RecyclerView listaMascotasFavoritas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascotas_favoritas);



        mascotas = new ArrayList<Mascota>();

        listaMascotasFavoritas = (RecyclerView) findViewById(R.id.rvMascotasFavoritas);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        listaMascotasFavoritas.setLayoutManager(llm);
        inicializarListaMascotas();
        inicializarAdaptador();


    }
    public MascotaAdaptador adaptador;
    public void inicializarAdaptador (){
        adaptador = new MascotaAdaptador(mascotas, this);
        listaMascotasFavoritas.setAdapter(adaptador);
    }


    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Shiba Inu", 3, R.drawable.shiba_inu_taiki, 5));
        mascotas.add(new Mascota("Bobtail", 4, R.drawable.bobtail, 5));
        mascotas.add(new Mascota("Labrador", 8 , R.drawable.labrador, 5));
        mascotas.add(new Mascota("Shar Pei", 2, R.drawable.shar_pei, 5));
        mascotas.add(new Mascota("Pastor alemán", 7, R.drawable.pastor_aleman, 5));

    }

}
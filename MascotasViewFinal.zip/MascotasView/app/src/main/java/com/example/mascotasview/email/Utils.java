package com.example.mascotasview.email;

public class Utils {
    public static final String EMAIL = "mascotasview@gmail.com";
    public static final String PASSWORD = "mascotas123";
}

package com.example.mascotasview.presentador;

import android.content.Context;

import com.example.mascotasview.db.ConstructorMascotas;
import com.example.mascotasview.fragment.InterfaceInicioFragment;
import com.example.mascotasview.pojo.Mascota;

import java.util.ArrayList;

public class InicioFragmentPresenter implements InterfaceInicioFragmentPresenter{

    private InterfaceInicioFragment interfaceInicioFragment;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;
    private Context context;

    public InicioFragmentPresenter(InterfaceInicioFragment interfaceInicioFragment, Context context) {
        this.interfaceInicioFragment = interfaceInicioFragment;
        this.context = context;
        obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatos();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        interfaceInicioFragment.inicializarAdaptadorRV(interfaceInicioFragment.crearAdaptador(mascotas));
        interfaceInicioFragment.generarLinearLayoutVertical();
    }
}

package com.example.mascotasview.presentador;

public interface InterfaceFragmentInicioPresenter {

    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();
}

package com.example.mascotasview.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mascotasview.R;
import com.example.mascotasview.adapter.MascotaAdaptador;
import com.example.mascotasview.adapter.MascotaAdaptador2;
import com.example.mascotasview.pojo.Mascota;
import com.example.mascotasview.presentador.FragmentInicioPresenter;
import com.example.mascotasview.presentador.InterfaceFragmentInicioPresenter;

import java.util.ArrayList;


public class FragmentInicio extends Fragment implements InterfaceFragmentInicio{



    public FragmentInicio() {
        // Required empty public constructor
    }
    ArrayList<Mascota> mascotas2;
    private RecyclerView listaMascota2;
    private InterfaceFragmentInicioPresenter presenter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View ver = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        listaMascota2 = (RecyclerView) ver.findViewById(R.id.rvMascotas);
        presenter = new FragmentInicioPresenter(this, getContext());
        return ver;
    }



    public void inicializarListaMascotas(){


    }

    @Override
    public void generarGridLayoutManager() {
        GridLayoutManager glm = new GridLayoutManager(getActivity(), 3);
        glm.setOrientation(GridLayoutManager.VERTICAL);
        listaMascota2.setLayoutManager(glm);

    }

    @Override
    public MascotaAdaptador2 crearAdaptador(ArrayList<Mascota> mascotas2) {
        MascotaAdaptador2 adaptador = new MascotaAdaptador2(mascotas2, getActivity());
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(MascotaAdaptador2 adaptador) {
        listaMascota2.setAdapter(adaptador);
    }
}
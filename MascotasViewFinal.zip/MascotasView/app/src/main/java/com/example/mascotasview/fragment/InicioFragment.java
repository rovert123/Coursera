package com.example.mascotasview.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mascotasview.R;
import com.example.mascotasview.adapter.MascotaAdaptador;
import com.example.mascotasview.pojo.Mascota;
import com.example.mascotasview.presentador.InicioFragmentPresenter;
import com.example.mascotasview.presentador.InterfaceInicioFragmentPresenter;

import java.util.ArrayList;

public class InicioFragment extends Fragment implements InterfaceInicioFragment {
    ArrayList<Mascota> mascotas;
    private RecyclerView listaMascota;
    private InterfaceInicioFragmentPresenter presenter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View v = inflater.inflate(R.layout.fragment_inicio2, container, false);
            mascotas = new ArrayList<Mascota>();
            listaMascota = (RecyclerView) v.findViewById(R.id.rvMascota);
            presenter = new InicioFragmentPresenter(this, getContext());
            return v;
    }


    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascota.setLayoutManager(llm);
    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas, getActivity());
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador) {
        listaMascota.setAdapter(adaptador);
    }
}

package com.example.mascotasview.fragment;


import com.example.mascotasview.adapter.MascotaAdaptador2;
import com.example.mascotasview.pojo.Mascota;

import java.util.ArrayList;

public interface InterfaceFragmentInicio {

    public void generarGridLayoutManager();

    public MascotaAdaptador2 crearAdaptador(ArrayList<Mascota> mascotas);

    public void inicializarAdaptadorRV(MascotaAdaptador2 adaptador);
}

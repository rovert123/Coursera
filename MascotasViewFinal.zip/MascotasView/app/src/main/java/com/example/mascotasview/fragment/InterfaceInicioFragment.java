package com.example.mascotasview.fragment;

import com.example.mascotasview.adapter.MascotaAdaptador;
import com.example.mascotasview.pojo.Mascota;

import java.util.ArrayList;

public interface InterfaceInicioFragment {

    public void generarLinearLayoutVertical();

    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);

    public void inicializarAdaptadorRV(MascotaAdaptador adaptador);
}

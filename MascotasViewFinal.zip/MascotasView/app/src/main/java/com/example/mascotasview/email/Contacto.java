package com.example.mascotasview.email;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mascotasview.R;
import com.example.mascotasview.email.JavaMailAPI;

public class Contacto extends AppCompatActivity {

    private EditText mEmail, mNombre, mMensaje;
    private Button enviarEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);
        mEmail = (EditText) findViewById(R.id.IDEmail);
        mNombre = (EditText) findViewById(R.id.IDNombre);
        mMensaje = (EditText) findViewById(R.id.IDMensaje);
        enviarEmail = (Button) findViewById(R.id.buttonEnviar);

        enviarEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarEmail();
            }
        });
    }



    private void enviarEmail(){
        String  email = mEmail.getText().toString().trim();
        String  mensaje = mMensaje.getText().toString().trim();
        String nombre = mNombre.getText().toString().trim();

        JavaMailAPI javaMailAPI = new JavaMailAPI(this, email,mensaje,nombre);

        javaMailAPI.execute();
    }

}
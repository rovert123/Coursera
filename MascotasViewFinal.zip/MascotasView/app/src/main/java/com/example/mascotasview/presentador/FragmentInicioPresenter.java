package com.example.mascotasview.presentador;

import android.content.Context;

import com.example.mascotasview.db.ConstructorMascotas;
import com.example.mascotasview.fragment.InterfaceFragmentInicio;
import com.example.mascotasview.pojo.Mascota;

import java.util.ArrayList;

public class FragmentInicioPresenter implements InterfaceFragmentInicioPresenter{

    private InterfaceFragmentInicio interfaceFragmentInicio;

    private ConstructorMascotas constructorMascotas;

    private ArrayList<Mascota> mascotas;

    private Context context;

    public FragmentInicioPresenter(InterfaceFragmentInicio interfaceFragmentInicio, Context context) {
        this.interfaceFragmentInicio = interfaceFragmentInicio;
        this.context = context;
        obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatos2();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        interfaceFragmentInicio.inicializarAdaptadorRV(interfaceFragmentInicio.crearAdaptador(mascotas));
        interfaceFragmentInicio.generarGridLayoutManager();
    }
}

package com.example.mascotasview.interfaces;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.mascotasview.R;

public class detalle_mascota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_mascota);

        Bundle parametros = getIntent().getExtras();
        String nombre = parametros.getString("nombre");
        String edad = parametros.getString("edad");
        String likes = parametros.getString("like");

        TextView tvNombre = (TextView) findViewById(R.id.tvNombre);
        TextView tvEdad = (TextView) findViewById(R.id.tvEdad);
        TextView tvLikes = (TextView) findViewById(R.id.tvLikes);

        tvNombre.setText(nombre);
        tvEdad.setText(edad);
        tvLikes.setText(likes);

    }
}
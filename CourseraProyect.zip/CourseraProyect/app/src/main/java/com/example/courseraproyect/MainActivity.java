package com.example.courseraproyect;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageButton btnFecha;

    Button btnSiguente;
    EditText nombre, email, telefono,fecha, descripcion;
    private int dia, mes, año;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = (EditText) findViewById(R.id.EditTextNombre);
        email = (EditText) findViewById(R.id.EditTextEmail);
        telefono = (EditText) findViewById(R.id.EditTextTelefono);
        descripcion = (EditText) findViewById(R.id.EditTextDescripcion);
        btnSiguente = (Button) findViewById(R.id.buttonSiguiente);
        btnFecha = (ImageButton) findViewById(R.id.ButtonFecha);
        fecha = (EditText) findViewById(R.id.EditTextDate);
        btnFecha.setOnClickListener(this);
        btnSiguente.setOnClickListener(this::Siguente);
    }


    @Override
    public void onClick(View view) {
        if(view==btnFecha){
            final Calendar c= Calendar.getInstance();
            dia=c.get(Calendar.DAY_OF_MONTH);
            mes=c.get(Calendar.MONTH);
            año=c.get(Calendar.YEAR);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                   fecha.setText(dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
                }
            }
            ,dia, mes, año);
            datePickerDialog.show();
        }
    }
    private void Siguente(View view) {
        Intent MiIntent = new Intent(MainActivity.this, ConfirmarContacto.class);
        Bundle MiBundle = new Bundle();
        MiBundle.putString("nombre", nombre.getText().toString());
        MiBundle.putString("fecha", fecha.getText().toString());
        MiBundle.putString("telefono", telefono.getText().toString());
        MiBundle.putString("email", email.getText().toString());
        MiBundle.putString("descripcion", descripcion.getText().toString());
        MiIntent.putExtras(MiBundle);
        startActivity(MiIntent);
    }
}
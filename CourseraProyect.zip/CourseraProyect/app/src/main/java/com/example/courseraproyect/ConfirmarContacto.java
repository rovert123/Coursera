package com.example.courseraproyect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConfirmarContacto extends AppCompatActivity {
    Button btnEditar;
    TextView campo1, campo2, campo3, campo4, campo5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_contacto);
        campo1 = (TextView) findViewById(R.id.campo1);
        campo2 = (TextView) findViewById(R.id.campo2);
        campo3 = (TextView) findViewById(R.id.campo3);
        campo4 = (TextView) findViewById(R.id.campo4);
        campo5 = (TextView) findViewById(R.id.campo5);
        btnEditar = (Button) findViewById(R.id.buttonRegresar);
        btnEditar.setOnClickListener(this::Onclicks);
        Bundle MiBundle=this.getIntent().getExtras();
        if(MiBundle!=null){
            String nombre = MiBundle.getString("nombre");
            campo1.setText(nombre);
            String  fecha = (MiBundle.getString("fecha"));
            campo2.setText(fecha);
            String telefono = MiBundle.getString("telefono");
            campo3.setText(telefono);
            String email = MiBundle.getString("email");
            campo4.setText(email);
            String descripcion = MiBundle.getString("descripcion");
            campo5.setText(descripcion);
        }

    }

    private void Onclicks(View view) {
        Intent MiIntent=null;
        MiIntent = new Intent(ConfirmarContacto.this, MainActivity.class);
        startActivity(MiIntent);
    }
}
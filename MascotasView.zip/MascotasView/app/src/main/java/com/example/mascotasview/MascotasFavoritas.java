package com.example.mascotasview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MascotasFavoritas extends AppCompatActivity {

    ArrayList<Mascota> mascotas;

    private RecyclerView listaMascotasFavoritas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascotas_favoritas);



        mascotas = new ArrayList<Mascota>();

        listaMascotasFavoritas = (RecyclerView) findViewById(R.id.rvMascotasFavoritas);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        listaMascotasFavoritas.setLayoutManager(llm);
        inicializarListaMascotas();
        inicializarAdaptador();


    }
    public MascotaAdaptador adaptador;
    public void inicializarAdaptador (){
        adaptador = new MascotaAdaptador(mascotas, this);
        listaMascotasFavoritas.setAdapter(adaptador);
    }


    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Shiba Inu", "3 Años", R.drawable.shiba_inu_taiki, "5 Likes"));
        mascotas.add(new Mascota("Bobtail", "4 Años", R.drawable.bobtail, "5 Likes"));
        mascotas.add(new Mascota("Labrador", "8 Años" , R.drawable.labrador, "5 Likes"));
        mascotas.add(new Mascota("Shar Pei", "2 Años", R.drawable.shar_pei, "5 Likes"));
        mascotas.add(new Mascota("Pastor alemán", "7 Años", R.drawable.pastor_aleman, "5 Likes"));

    }

}
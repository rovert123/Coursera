package com.example.mascotasview.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mascotasview.R;
import com.example.mascotasview.adapter.MascotaAdaptador;
import com.example.mascotasview.pojo.Mascota;

import java.util.ArrayList;


public class FragmentInicio extends Fragment {



    public FragmentInicio() {
        // Required empty public constructor
    }
    ArrayList<Mascota> mascotas;
    private RecyclerView listaMascota;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View ver = inflater.inflate(R.layout.fragment_inicio2, container, false);
        mascotas = new ArrayList<Mascota>();
        listaMascota = (RecyclerView) ver.findViewById(R.id.rvMascota);

        //LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        //llm.setOrientation(LinearLayoutManager.VERTICAL);

        GridLayoutManager glm = new GridLayoutManager(getActivity(), 2);


        listaMascota.setLayoutManager(glm);
        inicializarListaMascotas();
        inicializarAdaptador();
        return ver;
    }

    public MascotaAdaptador adaptador;
    public void inicializarAdaptador (){
        adaptador = new MascotaAdaptador(mascotas, getActivity());
        listaMascota.setAdapter(adaptador);
    }


    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Shar Pei", "2 Años", R.drawable.shar_pei, "5 Likes"));
        mascotas.add(new Mascota("Shiba Inu", "3 Años", R.drawable.shiba_inu_taiki, "5 Likes"));
        mascotas.add(new Mascota("Bobtail", "4 Años", R.drawable.bobtail, "5 Likes"));
        mascotas.add(new Mascota("Labrador", "8 Años" , R.drawable.labrador, "5 Likes"));
        mascotas.add(new Mascota("Pastor alemán", "7 Años", R.drawable.pastor_aleman, "5 Likes"));

    }
}
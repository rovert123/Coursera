package com.example.mascotasview;

public class Mascota {

    public String nombre;
    public String edad;
    public int foto;
    public String likes;


    public Mascota(String nombre, String edad, int foto, String likes) {
        this.nombre = nombre;
        this.edad = edad;
        this.foto = foto;
        this.likes = likes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getLikes() {
        return likes;
    }

    public void setLikes(String likes) {
        this.likes = likes;
    }
}

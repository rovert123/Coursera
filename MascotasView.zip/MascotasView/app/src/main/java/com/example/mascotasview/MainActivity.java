package com.example.mascotasview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.mascotasview.adapter.PageAdapter;
import com.example.mascotasview.fragment.FragmentInicio;
import com.example.mascotasview.fragment.InicioFragment;
import com.example.mascotasview.pojo.Mascota;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

import com.example.mascotasview.adapter.MascotaAdaptador;

public class MainActivity extends AppCompatActivity {


    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        setUpViewPager();


        /*
        */

        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }

    }
    private ArrayList<Fragment> agregarFragments(){
        ArrayList<Fragment> fragments = new ArrayList<>();
        fragments.add(new InicioFragment());
        fragments.add(new FragmentInicio());
        return fragments;
    }

    private void setUpViewPager(){
        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(), agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_casa);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_perro);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mHueso){
            Intent intent = new Intent(this, MascotasFavoritas.class);
            startActivity(intent);
        }else if (id == R.id.mAcerca){
            Intent intent = new Intent(this, Acerca.class);
            startActivity(intent);
        }else if (id == R.id.mContacto){
            Intent intent = new Intent(this, Contacto.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    public void irFavoritos (View v){
        Intent intent = new Intent(this, MascotasFavoritas.class);
        startActivity(intent);
    }

}
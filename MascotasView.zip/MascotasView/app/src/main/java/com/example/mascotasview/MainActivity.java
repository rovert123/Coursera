package com.example.mascotasview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);


        mascotas = new ArrayList<Mascota>();

        listaMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        listaMascotas.setLayoutManager(llm);
        inicializarListaMascotas();
        inicializarAdaptador();


        /*
        ListView lstMascotas = (ListView) findViewById(R.id.lsMascotas);
        lstMascotas.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nombreMascotas));

        lstMascotas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, detalle_mascota.class);
                intent.putExtra(getResources().getString(R.string.pnombre), mascotas.get(position).getNombre());
                intent.putExtra(getResources().getString(R.string.pedad), mascotas.get(position).getEdad());
                intent.putExtra(getResources().getString(R.string.pfoto), mascotas.get(position).getFoto());
                intent.putExtra(getResources().getString(R.string.plikes), mascotas.get(position).getLikes());
                startActivity(intent);
                finish();
            }
        });*/
    }
    public void irFavoritos (View v){
        Intent intent = new Intent(this, MascotasFavoritas.class);
        startActivity(intent);
    }
    public MascotaAdaptador adaptador;
    public void inicializarAdaptador (){
        adaptador = new MascotaAdaptador(mascotas, this);
        listaMascotas.setAdapter(adaptador);
    }


    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Labrador", "8 Años" , R.drawable.labrador, "5 Likes"));
        mascotas.add(new Mascota("Bobtail", "4 Años", R.drawable.bobtail, "5 Likes"));
        mascotas.add(new Mascota("Shiba Inu", "3 Años", R.drawable.shiba_inu_taiki, "5 Likes"));
        mascotas.add(new Mascota("Shar Pei", "2 Años", R.drawable.shar_pei, "5 Likes"));
        mascotas.add(new Mascota("Pastor alemán", "7 Años", R.drawable.pastor_aleman, "5 Likes"));

    }
}